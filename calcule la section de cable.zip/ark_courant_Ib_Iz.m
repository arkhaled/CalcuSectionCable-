function [Ib,Iz]=ark_courant_Ib_Iz(Pu,tension,rend,FP,b,c,d)
clc 
ark_FOpen('arKhaled/copyright') ;
a=1/(rend*FP);
switch tension
    case 127
        e=8;
    case 230
        fprintf('C''est quoi le type de l''installation :\n 1-:monophase \n 2-:triphas�\n')
        choix_Type_Install=ark_Test_Arret.Input_Valeur(2); 
        if choix_Type_Install ==1
            e=4.35;
        elseif choix_Type_Install ==2
            e=2.5;
        end
    case 400
        e=1.4 ;
 
       
end
Ib= Pu*a*b*c*d*e;
In=ceil(Ib);
fprintf('Le type de Protection\n 1-:disjoncteur \n 2-:Fisuble\n ')
type_Protection=ark_Test_Arret.Input_Valeur(2);  
if type_Protection==1
    Iz=In;
elseif type_Protection==2
    if In<=10
        Iz=1.31*In;
    elseif 10<In && In<=25
         Iz=1.21*In;
    elseif In>25
         Iz=1.1*In;  
    end
 end
    
    
    
