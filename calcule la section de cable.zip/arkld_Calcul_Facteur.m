function factr_Cor=arkld_Calcul_Facteur(cas)
    [LS , F0]=ark_N_Lettre_Sel(cas); 
    lettre={  'B','C','E','F'};
    if sum(strcmp(lettre,LS{2}))==true &  length(LS{1})==3 
            if LS{1}== '22A' |  LS{1}== '23A' 
                   fc=[ark_Facteur_Correction(1) ark_Facteur_Correction(4,LS) ark_Facteur_Correction(5) ark_Facteur_Correction(6) ] ;
            elseif   LS{1}== '24A'
                  fc=[ark_Facteur_Correction(1) ark_Facteur_Correction(4,LS) ark_Facteur_Correction(5) ark_Facteur_Correction(7)] ;
            else
                 fc=[ark_Facteur_Correction(1) ark_Facteur_Correction(4,LS) ark_Facteur_Correction(5)] ;
            end   
    elseif LS{2}=='D'
                
        if   LS{1}== '61'
                 fc=[ark_Facteur_Correction(2) ark_Facteur_Correction(3) ark_Facteur_Correction(8) ark_Facteur_Correction(9)] ;
        elseif   LS{1}== '62' |  LS{1}== '63'
               fc=[ark_Facteur_Correction(2) ark_Facteur_Correction(3)  ark_Facteur_Correction(10)] ;
 
         end
    else
                         fc=[ark_Facteur_Correction(1) ark_Facteur_Correction(4,LS) ark_Facteur_Correction(5)] ;
     end
factr_Cor=[LS F0 fc];

