 
%% Realise par : 
%%                                   -ARARIA KHALED              -ADDA BOUCIF
%% Dergir par : 
%%                                                       BEKKI  I          
%
%% PROGRAM  DETERMINATION DES SECTIONS DE CONDUCTEURS
%   Pour d�terminer la section des conducteurs de phases, il faut proc�der de la fa�on suivante :
%       �	D�terminer le courant maximal d�emploi
%       �	Rechercher le dispositif de protection
%       �	D�terminer le courant admissible dans les canalisations
%       �	En d�duire la section des conducteurs
%
%% ------------------------------  Star Programe  --------------------------------%
while true
clear
clc 
ark_FOpen('arKhaled/copyright') ;

%% ------------------------ Input les donnes  -----------------------------------%
msgPu='La puissance utile en (kW):  ';
Pu=ark_Test_Arret.input_valeur(inf,msgPu);
msgU='La tension  en (V): ';
U=ark_Test_Arret.voltg(msgU);
msgr='Le rendement : r= ';
r=ark_Test_Arret.input_valeur(inf,msgr);
 msgfp='Facteur de puissance FP : ';
fp=ark_Test_Arret.input_valeur(inf,msgfp);
msgb='Facteur d''utilisation des appareils: b=';
b=ark_Test_Arret.input_valeur(inf,msgb);
msgc='Facteur de simultan�it�: c=';
c=ark_Test_Arret.input_valeur(inf,msgc);
msgd='Facteur tenant compte des pr�visions d''extension : d= ';
d=ark_Test_Arret.input_valeur(inf,msgd);
%
%%  D�terminer le courant maximal d�emploi et le courant admissible dans la canalisation 

[Ib, Iz]=ark_courant_Ib_Iz(Pu,U,r,fp,b,c,d);   
fprintf('\n\tLe courant maximal d''emploi :   \tIb=%.3f A \n\n\tLe courants admissibles dans les canalisations:   \tIz=%.1f A  \n\n',Ib,Iz)


%% 	Rechercher le dispositif de protection  et 	D�termination du facteur de correction F

ark_FOpen('arKhaled/modeDePose') ;
choix_Dispositif_Protection=ark_Test_Arret.Input_Valeur(18);
F=arkld_Calcul_Facteur(choix_Dispositif_Protection);
f=F{4};
        if length(f)==3
                Fg=F{3}*f(1)*f(2)*f(3);
        else
                Fg=F{3}*f(1)*f(2)*f(3)*f(4);
        end
      
        disp('-------------------------------------------------')
        fprintf('\n\tNumero :\t %s\n\tLettre de s�lection:\t%s\n\n',F{1},F{2});
         fprintf('Facteurs de correction:\t \tf0=%.3f\n',F{3});
         if F{2}=='B' | F{2}=='C' | F{2}=='E' | F{2}=='F'
              fprintf('Facteurs de correction:\t \tf1=%.3f\n',f(1));
              fprintf('Facteurs de correction :\t \tf4=%.3f\n',f(2));
              fprintf('Facteurs de correction :\t \tf5=%.3f\n',f(3));
         elseif length(F{1})==3
             if F{1}=='22A' | F{1}=='23A'
                  fprintf('Facteurs de correction :\t \tf6=%.3f\n',f(4));
             elseif F{1}=='24A'
                 fprintf('Facteurs de correction :\t \tf7=%.3f\n',f(4));
             end
             
        elseif length(F{1})==2 | F{2}=='D'
             fprintf('Facteurs de correction:\t \tf2=%.3f\n',f(1));
             fprintf('Facteurs de correction :\t \tf3=%.3f\n',f(2));
            if F{1}=='61' 
                fprintf('Facteurs de correction :\t \tf8=%.3f\n',f(3));
                fprintf('Facteurs de correction :\t \tf9=%.3f\n',f(4));
            elseif F{1}=='62' |F{1}=='63' 
                fprintf('Facteurs de correction :\t \tf10=%.3f\n',f(3));
            end
        end
        disp('-------------------------------------------------')
        fprintf('Facteurs global :\t  \tFg=%f\n\n',Fg);
        disp('-------------------------------------------------')
%% Le courant admissible dans la canalisation en fonction des influence exterieures Iz'
Iadm=Iz/Fg;
fprintf('\tLe courants admissibles :   \tIz''=%.3f A  \n',Iadm)
        disp('-------------------------------------------------')
%% d�termination  la section pouvant v�hiculer dans les conditions standards d'installation
section_Cable=ark_Section_Cable(Iadm,F{2});
if ischar(section_Cable)==true 
          disp('-------------------------------------------------')
          fprintf('\t%s',section_Cable)
         disp('-------------------------------------------------')
else
        disp('-------------------------------------------------')
        fprintf('\n\tLa section de cable  est  :   \tS=%.1f mm�  \n',section_Cable)
        disp('-------------------------------------------------')
end
quit=input ( 'Voulez-vous continuer, Y / N [Y]:' , 's' );
if quit=='N' | quit=='n'
    break
end
                     
    
end

