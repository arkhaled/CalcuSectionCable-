function [N_Lettre_Sel, f0]=ark_N_Lettre_Sel(cas)
switch cas
    case 1
        N_Lettre_Sel={'11' 'C'};
        f0=1;
       
    case 2
        N_Lettre_Sel={'11A'  'C'};
        f0=0.95;
    case 3
        N_Lettre_Sel={'12' 'C'};
        f0=1;
    case 4
        fprintf('Le type de cable utilise\n 1-:multiconducteurs\n 2-:monoconducteurs \n')
        type_Cable=ark_Test_Arret.Input_Valeur(2); 
      
        ark_FOpen('arKhaled/mp4');
        Choix_modes_Pose =ark_Test_Arret.Input_Valeur_MP(41,42,43);
       
        if type_Cable==1
            switch Choix_modes_Pose
                case 41
                    N_Lettre_Sel={'13' 'E'};
                    f0=1;
                case 42
                     N_Lettre_Sel={'14' 'E'};
                     f0=1;
                case 43 
                    N_Lettre_Sel={'16' 'E'};
                    f0=1;
            end
        elseif type_Cable==2
            switch Choix_modes_Pose
                case 41
                    N_Lettre_Sel={'13' 'F'};
                    f0=1;
                case 42
                    N_Lettre_Sel={'14' 'F'};
                    f0=1;
                case 43 
                    N_Lettre_Sel={'16' 'F'};
                    f0=1;
            end           
        end
    case 5
        N_Lettre_Sel={'21' 'B'};
        f0=0.95;
    case 6
         N_Lettre_Sel={'22A' 'B'};
         f0=0.865;
    case 7
         N_Lettre_Sel={'23A' 'B'};
         f0=0.865;
    case 8
         N_Lettre_Sel={'24A' 'B'};
         f0=0.865;
    case 9
         N_Lettre_Sel={'25' 'B'};
         f0=0.95;
    case 10 
         N_Lettre_Sel={'31A' 'B'};
         f0=0.9;
    case 11 
          N_Lettre_Sel={'32A' 'B'};
          f0=0.9;
    case 12
         N_Lettre_Sel={'33A' 'B'};
         f0=0.9;
    case 13
         N_Lettre_Sel={'34A' 'B'};
         f0=0.9;
    case 14 
         N_Lettre_Sel={'41' 'B'};
         f0=0.95;
    case 15 
         N_Lettre_Sel={'43' 'B'};
         f0=1;
    case 16    
         N_Lettre_Sel={'61' 'D'};
         f0=0.8;
    case 17
         N_Lettre_Sel={'62' 'D'};
         f0=1;
    case 18
         N_Lettre_Sel={'63' 'D'};
         f0=1;
end

    
















































         
        
    
    
