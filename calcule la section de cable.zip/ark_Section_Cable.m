function [Sc]=ark_Section_Cable(courant_Adm,letre_Selection)
    %les Donnes: la Lettre de s�lection et Isolant et nombre de conducteurs charg�s
    donne_Letre_Section={'B','C','D','E','F'};
    donne_Type_Isolant={'PVC2', 'PVC3','PR2','PR3'};
        disp('L''isolant et nombre de conducteurs charges est:')
        for i=1:length(donne_Type_Isolant)
            fprintf('  %d-:%s\n',i,donne_Type_Isolant{i})
            if i==length(donne_Type_Isolant)
              choix_Isolon=ark_Test_Arret.Input_Valeur(4);%   input('Entrer >>');
            end
        end
    for i=1:length(donne_Letre_Section)
        if donne_Letre_Section{i}==letre_Selection 
            for j=1:length(donne_Type_Isolant)
                if length(donne_Type_Isolant{j})==length(donne_Type_Isolant{choix_Isolon})
                    if letre_Selection=='B'  % letre de section B 
                        if length(donne_Type_Isolant{choix_Isolon})==3
                             if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{3}
                                   disp('C6:PR2')   ;
                                   Sc=ark_Table_Section(7,courant_Adm,letre_Selection);
                             elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{4}
                                  disp('C3:PR3')   ;
                                  Sc=ark_Table_Section(5,courant_Adm,letre_Selection);
                             end
                        elseif  length(donne_Type_Isolant{choix_Isolon})==4
                            if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{1}
                                    disp('C2:PVC2');
                                   Sc=ark_Table_Section(3,courant_Adm,letre_Selection);
                            elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{2}
                                      disp('C1:PVC3');
                                      Sc=ark_Table_Section(2,courant_Adm,letre_Selection);
                            end
                        end
                    end         
     % La section de la lettre C          
                    if letre_Selection=='C'  
                        if length(donne_Type_Isolant{choix_Isolon})==3
                             if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{3}
                                  disp('C6:PR2')   ;
                                   Sc=ark_Table_Section(8,courant_Adm,letre_Selection);
                             elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{4}
                                  disp('C3:PR3')   ;
                                   Sc=ark_Table_Section(6,courant_Adm,letre_Selection);           
                             end
                        elseif  length(donne_Type_Isolant{choix_Isolon})==4
                            if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{1}
                                   Sc=ark_Table_Section(5,courant_Adm,letre_Selection);
                            elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{2}
                                   Sc=ark_Table_Section(3,courant_Adm,letre_Selection);
                            end
                        end
                    end
    %Pour la lettre section E
                    if letre_Selection=='E'  % 
                        if length(donne_Type_Isolant{choix_Isolon})==3
                             if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{3}
                                   disp('C6:PR2')   ;
                                   Sc=ark_Table_Section(8,courant_Adm,letre_Selection);
                             elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{4}
                                  disp('C3:PR3')   ;
                                   Sc=ark_Table_Section(6,courant_Adm,letre_Selection);
                             end
                        elseif  length(donne_Type_Isolant{choix_Isolon})==4
                            if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{1}
                                      disp('C2:PVC2');
                                     Sc=ark_Table_Section(3,courant_Adm,letre_Selection);
                            elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{2}
                                      disp('C1:PVC3');
                                      Sc=ark_Table_Section(3,courant_Adm,letre_Selection);
                            end
                        end
                    end
      %Pour la lettre F 
                    if letre_Selection=='F'  % 
                        if length(donne_Type_Isolant{choix_Isolon})==3
                             if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{3}
                                   disp('C6:PR2')   ;
                                 Sc=ark_Table_Section(8,courant_Adm,letre_Selection);
                             elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{4}
                                  disp('C3:PR3')  ; 
                                 Sc=ark_Table_Section(6,courant_Adm,letre_Selection);
                             end
                        elseif  length(donne_Type_Isolant{choix_Isolon})==4
                            if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{1}
                                      disp('C2:PVC2');
                                      Sc=ark_Table_Section(5,courant_Adm,letre_Selection);
                            elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{2}
                                      disp('C1:PVC3');
                                      Sc=ark_Table_Section(3,courant_Adm,letre_Selection);
                            end
                        end
                    end
  %Pour la lettre F 
                       if letre_Selection=='D'  % 
                        if length(donne_Type_Isolant{choix_Isolon})==3
                             if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{3}
                                   disp('C6:PR2')   ;
                                 Sc=ark_Table_Section(4,courant_Adm,letre_Selection);
                             elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{4}
                                  disp('C3:PR3')  ; 
                                 Sc=ark_Table_Section(3,courant_Adm,letre_Selection);
                             end
                        elseif  length(donne_Type_Isolant{choix_Isolon})==4
                            if donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{1}
                                      disp('C2:PVC2');
                                      Sc=ark_Table_Section(2,courant_Adm,letre_Selection);
                            elseif donne_Type_Isolant{choix_Isolon}==donne_Type_Isolant{2}
                                      disp('C1:PVC3');
                                      Sc=ark_Table_Section(1,courant_Adm,letre_Selection);
                            end
                        end
                       end
                    
                    break 
                end                
            end
            break
        end
    end