classdef ark_Test_Arret
    methods(Static)
        function rtn_v=voltg(msg)
            fprintf('\nEntrer la valeur de %s\n\n',msg);
           while true 
                choix=input('Entrer >>','s');
                     choix=str2double(choix);
                     if choix>=114.3 && choix <=139.7
                         rtn_v= 127;
                         break
                     elseif choix>=207 && choix <=253
                         rtn_v=230;
                         break
                         elseif choix>=342 && choix <=418
                         rtn_v= 400;
                         break
                     else
                        fprintf('\nLa valeur entr�e doit �tre �gal -+10%% � la valeur de tension nominal:127,230,380\n\n')
                        continue
                     end
           end
        end
        
        function rtn_mp=Input_Valeur_MP(nbre1,nbre2,nbre3)
              while true 
                choix=input('Entrer >>','s');
                     choix=str2double(choix);
                     if choix==nbre1
                         rtn_mp= (choix);
                         break
                     elseif choix==nbre2
                         rtn_mp= (choix);
                         break
                         elseif choix==nbre3
                         rtn_mp= (choix);
                         break
                     else
                        fprintf('La valeur entr�e doit �tre �gal ces valeurs : %d,%d,%d\n\n',nbre1,nbre2,nbre3)
                        continue
                     end
               end
        
        end 
        function rtn_f=Input_Valeur(nbre)
              while true 
                choix=input('Entrer >>','s');
                     choix=str2double(choix);
                     if choix<=nbre
                         rtn_f= (choix);
                         break
                     else
                        fprintf('\nLa valeur entr�e doit �tre inf�rieure � %d\n\n',nbre)
                        continue
                     end
               end
        
        end  
        function rtn_f2=input_valeur(nbre,msg)
            while true 
                fprintf('\nEntrer la valeur de %s\n\n',msg);
                choix=input('Entrer >>','s');
                     choix=str2double(choix);
                     if choix<=nbre
                         rtn_f2= (choix);
                         break
                     else
                        continue
                     end
            end
        
         
        end
     end
end