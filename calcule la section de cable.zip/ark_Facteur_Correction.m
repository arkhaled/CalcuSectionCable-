function f=ark_Facteur_Correction(cas,lettre_Selection)  

 switch cas               
    case 1 
        j=1;
        fprintf('C''est quoi la valeur de Temperatures ambiantes (�C)(f1:canalisations non enterr�es):\n')
        temperatures_Ambiantes=ark_Test_Arret.Input_Valeur(80);       
        fprintf('\nC''est quoi le type de l''isolation:\n   1-:Elastomeres(caoutchouc)\n   2-:PVC\n   3-:PR et EPR\n\n')
        type_Isolon=ark_Test_Arret.Input_Valeur(3);       
        teta0=[10  15  20  25  35  40  45 50 55 60 65 70 75 80];
        if type_Isolon==1 && temperatures_Ambiantes<=50
            tetap=[1.29 1.22 1.15 1.07 0.93 0.82 .71 .58];  
            j=1;
            for i=teta0
                 if i==temperatures_Ambiantes
                      f=sqrt((tetap(j)-teta0(j))/(tetap(j)-30));
                 end
                 j=j+1;                 
            end 
        elseif type_Isolon==2 && temperatures_Ambiantes<=60
            tetap=[1.22 1.17 1.12 1.06 .94 .87 .79 .71 .61 .5];            
             j=1;
            for i=teta0
                 if i==temperatures_Ambiantes
                      f=sqrt((tetap(j)-teta0(j))/(tetap(j)-30));
                 end
                 j=j+1;                 
            end
        elseif type_Isolon==3 && temperatures_Ambiantes<=80
            tetap=[1.15 1.12 1.08 1.04 .96 .91 .87 .82 .76 .71 .65 .58 .5 .41 ];            
            for i=teta0
                 if i==temperatures_Ambiantes
                      f=sqrt((tetap(j)-teta0(j))/(tetap(j)-30));
                 end
                 j=j+1;                 
            end
        end
    case 2 
        fprintf('La valeur de Temperatures ambiantes (�C)(f2:canalisations enterr�es):\n')
        temperatures_Ambiantes=ark_Test_Arret.Input_Valeur(80);      
        j=1;
        fprintf('\n\nLe type de l''isolation:\n   1-:PVC\n   2-:PR et EPR\n\n')
        type_Isolon=ark_Test_Arret.Input_Valeur(2);       
        if type_Isolon==1 && temperatures_Ambiantes<=60
            tetap=[1.1 1.05 .95 .89 .84 .77 .71 .63 .55 .45];            
            teta0=10:5:80;
            for i=teta0
                 if i==temperatures_Ambiantes
                      f=sqrt((tetap(j)-teta0(j))/(tetap(j)-20));
                 end
                 j=j+1;                 
            end
        elseif type_Isolon==2 && temperatures_Ambiantes<=80
            tetap=[1.07 1.04 .94 .93 .89 .85 .80 .76 .71 .65 .60 .53 .46 .38 ];            
            teta0=10:5:80;
            for i=teta0
                 if i==temperatures_Ambiantes
                      f=sqrt((tetap(j)-teta0(j))/(tetap(j)-20));
                 end
                 j=j+1;                 
             end
        end        
    case 3   
        fprintf('La valeur de Resistivite thermique du terrain en K.m/W :\n')
        in_Resistivite_Thermique =ark_Test_Arret.Input_Valeur(3.5);       
        resistivite_Thermique=[.4 .5 .7 .85 1 1.2 1.5 2 2.5 3];
        fc3=[1.25 1.21 1.13 1.05 1 .94 .86 .76 .7 .65];
        for i=1:length(resistivite_Thermique )
            if in_Resistivite_Thermique ==resistivite_Thermique(i)
                f=fc3(i);
            end
        end
    case 4
         fprintf(' Nombre de c�bles multiconducteurs ou groupes\n\tde c�bles monoconducteurs jointifs :\n')
        nmbr_cabl_Mc_GMc =ark_Test_Arret.Input_Valeur(20);       
while true
        if nmbr_cabl_Mc_GMc >9
            if nmbr_cabl_Mc_GMc ==12 ||nmbr_cabl_Mc_GMc ==16 ||nmbr_cabl_Mc_GMc ==20
              if nmbr_cabl_Mc_GMc==12
                nmbr_cabl_Mc_GMc=10;
              elseif nmbr_cabl_Mc_GMc==16
                nmbr_cabl_Mc_GMc=11;
              elseif nmbr_cabl_Mc_GMc==20
                 nmbr_cabl_Mc_GMc=12;
               end
            end
        end
        f41=[1 0.8 0.7 0.65 0.6 0.55 0.55 0.50 0.50 0.45 0.4 0.4];
        f42=[1 .85 .79 .75 .73 .72 .72 .71 .70];
        f43=[1 .85 .76 .72 .69 .67 .66 .65 .64];
        f44=[1 .88 .82 .77 .75 .73 .73 .72 .72];
        f45=[1 .88 .82 .80 .80 .79 .79 .78 .78];
        cas1={ '21','25','31', '22A','23A','24A','31A','32A','33A','34A','41','43'};
        cas2={'11' ,'12' };
        cas3={'11A'};
        cas4={'13'};
        cas5={'14','16'};
        N_modes_Pose={'11','13','12','14','16','21','25','31','11A','22A','23A','24A','31A','32A','33A','34A','41','43'};
          if find(strcmp(cas1,lettre_Selection{1}))>0
                    for i=1:length(N_modes_Pose)
                        if  length(N_modes_Pose{i})==2 &&  length(lettre_Selection{1})==2
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f41(nmbr_cabl_Mc_GMc);
                                break
                            end
                        elseif  length(N_modes_Pose{i})==3 &&  length(lettre_Selection{1})==3
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f41(nmbr_cabl_Mc_GMc);
                                break
                            end 
                        end
                    end       
                    break
                    
    
            elseif find(strcmp(cas2,lettre_Selection{1}))>0
                    if nmbr_cabl_Mc_GMc <=9
                    for i=1:length(N_modes_Pose)
                        if  length(N_modes_Pose{i})==2 &&  length(lettre_Selection{1})==2
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f42(nmbr_cabl_Mc_GMc);
                                break
                            end
                        elseif  length(N_modes_Pose{i})==3 &&  length(lettre_Selection{1})==3
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f42(nmbr_cabl_Mc_GMc);
                                break
                            end 
                        end
                    end       
                    break
                    end            

            elseif find(strcmp(cas3,lettre_Selection{1}))>0
                    if nmbr_cabl_Mc_GMc <=9
                    for i=1:length(N_modes_Pose)
                        if  length(N_modes_Pose{i})==2 &&  length(lettre_Selection{1})==2
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f43(nmbr_cabl_Mc_GMc);
                                break
                            end
                        elseif  length(N_modes_Pose{i})==3 &&  length(lettre_Selection{1})==3
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f43(nmbr_cabl_Mc_GMc);
                                break
                            end 
                        end
                    end       
                    break
                    end
            elseif find(strcmp(cas4,lettre_Selection{1}))>0
                 if nmbr_cabl_Mc_GMc <=9
                    for i=1:length(N_modes_Pose)
                        if  length(N_modes_Pose{i})==2 &&  length(lettre_Selection{1})==2
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f44(nmbr_cabl_Mc_GMc);
                                break
                            end
                        elseif  length(N_modes_Pose{i})==3 &&  length(lettre_Selection{1})==3
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f44(nmbr_cabl_Mc_GMc);
                                break
                            end 
                        end
                    end       
                    break
                 end
                     
            elseif find(strcmp(cas5,lettre_Selection{1}))>0
                    if nmbr_cabl_Mc_GMc <=9
                    for i=1:length(N_modes_Pose)
                        if  length(N_modes_Pose{i})==2 &&  length(lettre_Selection{1})==2
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f45(nmbr_cabl_Mc_GMc);
                                break
                            end
                        elseif  length(N_modes_Pose{i})==3 &&  length(lettre_Selection{1})==3
                            if N_modes_Pose{i}==lettre_Selection{1}
                                f=f45(nmbr_cabl_Mc_GMc);
                                break
                            end 
                        end
                    end       
                    break
                    end
                    end
end
          
    case 5
        fprintf(' Entre le nombre de Couches: \n')
        nmbrCouche=ark_Test_Arret.Input_Valeur(100);       
        if nmbrCouche==2
            f=0.8;
        elseif nmbrCouche==3
            f=0.73;
        elseif nmbrCouche==5 || nmbrCouche==6
            f=0.7;
        elseif 6<=nmbrCouche && nmbrCouche<=8
            f=0.68;
        elseif nmbrCouche>=9
            f=0.66;
        end                 
    case 6
        fprintf('Entre le Nombre de conduits dispos�s verticalement   :')
       NCDV=ark_Test_Arret.Input_Valeur(6); 
       fprintf('Entre le Nombre de conduits dispos�s horizontalement :>> ');
        NCDH= ark_Test_Arret.Input_Valeur(6); 
       fc6=[1 0.94 0.91 0.88 0.87 0.86;
              0.92 0.87 0.84 0.81 0.80 0.79;
              0.85 0.81 0.78 0.76 0.75 0.74;
              0.82 0.78 0.74 0.73 0.72 0.72;
              0.80 0.76 0.72 0.71 0.70 0.70;
              0.79 0.75 0.71 0.70 0.69 0.68];
       f=fc6(NCDV,NCDH);     
    case 7
       fprintf('Entre le Nombre de conduits dispos�s verticalement   :')
       NCDV=ark_Test_Arret.Input_Valeur(6); 
       fprintf('Entre le Nombre de conduits dispos�s horizontalement :>> ');
        NCDH= ark_Test_Arret.Input_Valeur(6); 
         fc7=[1 0.87 0.77 0.72 0.68 0.65 ;
          0.87 0.71 0.62 0.57 0.53 0.50 ;
          0.77 0.62 0.53 0.48 0.45 0.42 ;
          0.72 0.57 0.48 0.44 0.40 0.38 ;
          0.68 0.53 0.45 0.40 0.37 0.35 ;
          0.65 0.50 0.42 0.38 0.35 0.32 ];
       f=fc7(NCDV,NCDH);
    case 8
        fprintf('Distance entre conduits en m:[0.25,0.5,1]:  \n')
        DistCond=ark_Test_Arret.Input_Valeur(6); 
        fprintf('Nombre de conduits: \n')
        NmbrCond=ark_Test_Arret.Input_Valeur(6);
        fc8=[0.93 0.95 0.97;
            0.87 0.91 0.95;
            0.84 0.89 0.94;
            0.81 0.87 0.93;
            0.79 0.86 0.93];
        if DistCond==0.25
            f=fc8(NmbrCond,1);
        elseif DistCond==0.5
            f=fc8(NmbrCond,2);
        elseif DistCond==1
            f=fc8(NmbrCond,3);
        end    
    case 9
        fprintf('Nombre de circuits ou de cables multiconducteurs:[1,2,..,20] ')
        NmbCCM=ark_Test_Arret.Input_Valeur(6);
        fc9=[1 0.71 0.58 0.5 0.45 0.41 0.38 0.35 0.33 0.29 0.25 0.22];
        f=fc9(NmbCCM);
    case 10
        f=2;
%          [0.76 0.79 0.84 0.88 0.92;
%           0.64 0.67 0.74 0.79 0.85;
%           0.57 0.61 0.69 0.75 0.82;
%           0.52 0.56 0.65 0.71 0.80;
%           0.49 0.53 0.60 0.69 0.78]
end         

      
        
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
