function arKhaled= ark_FOpen(arkld)
fid =  fopen(arkld);
tLine = fgetl(fid);
while ischar(tLine)
    disp(tLine)
    tLine = fgetl(fid);
    arKhaled=tLine;
end
fclose(fid);

